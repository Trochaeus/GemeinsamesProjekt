package com.company;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class GUI {
    static String[][][] spielfeld;
    static Image[] imgs = new Image[8];
    static Image[] imgsExplosions = new Image[8];
    static String bildpfadGame = "C:\\Users\\Public\\Documents\\FlappyBirdImages\\FlappyBirdImagePack.png";
    static String bildpfadExplosion = "C:\\Users\\Public\\Documents\\FlappyBirdImages\\Explosion.png";
    static JPanel pn = new JPanel();
    static Frame newFrame = new JFrame();
    static int spielerHoehe;

    public static void setSpielfeld(String[][][] Spielfeld) {
        spielfeld = Spielfeld;
    }

    public static void ImportPictures () throws IOException {
        BufferedImage all1 = ImageIO.read(new File(bildpfadGame));
        int index1=0;
        for (int i = 0; i < 128; i+=64) {
            for (int j = 0; j < 256; j+=64) {
                imgs[index1] = all1.getSubimage(j,i,64,64).getScaledInstance(24,24,BufferedImage.SCALE_DEFAULT);
                index1++;
            }
        }
        BufferedImage all2 = ImageIO.read(new File(bildpfadExplosion));
        int index2=0;
        for (int i = 0; i < 128; i+=64) {
            for (int j = 0; j < 256; j+=64) {
                imgsExplosions[index2] = all2.getSubimage(j,i,64,64).getScaledInstance(24,24,BufferedImage.SCALE_DEFAULT);
                index2++;
            }
        }
    }

    public static void GuiErstellen () {
        newFrame = new JFrame();
        newFrame.setBounds(10,10,1200,240);
        newFrame.setLocationRelativeTo(null);
        newFrame.setUndecorated(true);
        RePrintGUI(spielfeld);

        newFrame.addMouseMotionListener(new MouseMotionListener() {
            public void mouseDragged(MouseEvent e) {}
            public void mouseMoved(MouseEvent e) {}
        });
        newFrame.addMouseListener(new MouseListener() {

            public void mousePressed(MouseEvent e) {Game.setSpaceIsPressed();}
            public void mouseClicked(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
            public void mouseEntered(MouseEvent e) {}
            public void mouseExited(MouseEvent e) {}
        });

        //newFrame.setDefaultCloseOperation(3);
        newFrame.setVisible(true);
    }
    public static void RePrintGUI(String[][][] spielfeld) {
        newFrame.remove(pn);
        pn = new JPanel() {
            public void paint(Graphics g) {
                for (int yAxis = 0; yAxis < spielfeld.length; yAxis++) {
                    for (int xAxis = 0; xAxis < spielfeld[0].length; xAxis++) {
                        for (int Layer = 0; Layer < spielfeld[0][0].length; Layer++) {
                            if (!spielfeld[yAxis][xAxis][Layer].equals("%")) {
                                //Layer 0: Bird, Layer 1: Tower, Layer 2: Background, % bedeutet leer
                                switch (spielfeld[yAxis][xAxis][Layer]) {
                                    case ".":
                                        if (spielfeld[yAxis][xAxis][0].equals("%") && spielfeld[yAxis][xAxis][1].equals("%")) {
                                            g.drawImage(imgs[2],xAxis*24,yAxis*24,this); //Wolken/Hintergrund NUR ANZEIGEN, wenn alles davor leer ist
                                        }
                                        break;
                                    case "~":
                                        if (spielfeld[yAxis][xAxis][0].equals("%") && spielfeld[yAxis][xAxis][1].equals("%")) {
                                            //Wolken/Hintergrund NUR ANZEIGEN, wenn alles davor leer ist
                                            g.drawImage(imgs[3],xAxis*24,yAxis*24,this);
                                        }
                                        break;
                                    case "|":
                                        if (spielfeld[yAxis][xAxis][0].equals("%")) {
                                            //Türme NUR ANZEIGEN, wenn alles davor leer ist
                                            g.drawImage(imgs[5],xAxis*24,yAxis*24,this);
                                        }
                                        break;
                                    case "#":
                                        if (spielfeld[yAxis][xAxis][0].equals("%")) {
                                            //Türme NUR ANZEIGEN, wenn alles davor leer ist
                                            g.drawImage(imgs[4],xAxis*24,yAxis*24,this);
                                        }
                                        break;
                                    case "+":
                                        if (spielfeld[yAxis][xAxis][0].equals("%")) {
                                            //Türme NUR ANZEIGEN, wenn alles davor leer ist
                                            g.drawImage(imgs[6],xAxis*24,yAxis*24,this);
                                        }
                                        break;
                                    case "*":
                                        g.drawImage(imgs[0],xAxis*24,yAxis*24,this); //Spieler IMMER ANZEIGEN
                                        break;
                                    case "/":
                                        g.drawImage(imgs[1],xAxis*24,yAxis*24,this); //Spieler IMMER ANZEIGEN
                                        break;
                                    default:
                                        g.drawImage(imgs[2],xAxis*24,yAxis*24,this); //Sollte eigentlich nicht vorkommen
                                        break;
                                }
                            }
                        }
                    }
                }
            }
        };
        //Redraw wird ausgeführt
        newFrame.add(pn);
        newFrame.revalidate();
    }
    public static void DeathScreenGUI(String[][][] Spielfeld, int Score, int HighScore) {
        spielfeld = Spielfeld;

        //Höhe des Spielers suchen
        spielerHoehe = spielfeld.length/2; //Eingabe sollte nie als Ergebnis rauskommen, ist nur da, damit IntelliJ leise ist. Wenn der Spieler nicht gefunden wird, wird die Animation in der Mitte des Screens gestartet
        for(int yAxis = 0; yAxis < spielfeld.length; yAxis++) {
            if(spielfeld[yAxis][spielfeld[0].length/2][0].equals("*")) {
                spielerHoehe = yAxis;
            }
        }
        //Animatationsframe 0
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[0],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[0],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 1
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[1],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[1],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 2
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[2],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[2],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 3
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[3],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[3],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 4
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[4],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[4],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 5
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[5],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[5],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 6
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[6],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[6],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 7
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                g.drawImage(imgsExplosions[7],spielfeld[0].length/2*24,spielerHoehe*24,this); //Explosion für Vogel
                g.drawImage(imgsExplosions[7],(spielfeld[0].length/2-1)*24,(spielerHoehe+1)*24,this); //Explosion für Vogel Anhängsel
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Animatationsframe 8
        pn = new JPanel() {
            public void paint(Graphics g) {
                for (int yAxis = 0; yAxis < spielfeld.length; yAxis++) {
                    for (int xAxis = 0; xAxis < spielfeld[0].length; xAxis++) {
                        if(spielfeld[yAxis][xAxis][2].equals("~")) {
                            g.drawImage(imgs[3], xAxis * 24, yAxis * 24, this);
                        }
                        else {
                            g.drawImage(imgs[2], xAxis * 24, yAxis * 24, this);
                        }
                    }
                }
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        //Score & HighScore
        pn = new JPanel() {
            public void paint(Graphics g) {
                //Animation an der Stelle des Spielers anzeigen
                String ScoreMessage = "Score: " + Score;
                String HighScoreMessage = "Highscore: " + HighScore;
                g.setColor(Color.GRAY);
                g.fillRect(570,80,104,74); // Schatten für Rahmen (Grau)
                g.setColor(Color.BLACK);
                g.fillRect(568,78,104,74); // Rahmen (Schwarz)
                g.setColor(Color.WHITE);
                g.fillRect(570,80,100,70); // Hintergrund für Text (Weiß)
                g.setColor(Color.BLACK);
                g.drawString("You're Dead.",580, 100); // Text (Schwarz)
                g.drawString(ScoreMessage,580, 120);
                g.drawString(HighScoreMessage,580, 140);
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        try {Thread.sleep(4000);} catch (InterruptedException e) {e.printStackTrace();}
    }
    /*
    public static void StartScreenGUI() {
        //Score & HighScore
        pn = new JPanel() {
            public void paint(Graphics g) {
                g.setColor(Color.GRAY);
                g.fillRect(69,69,605,205); // Schatten für Rahmen (Grau)
                g.setColor(Color.BLACK);
                g.fillRect(68,68,604,204); // Rahmen (Schwarz)
                g.setColor(Color.WHITE);
                g.fillRect(70,70,600,200); // Hintergrund für Text (Weiß)
                g.setColor(Color.BLACK);
                g.drawString(":D",580, 100); // Text (Schwarz)
            }
        };
        newFrame.add(pn);
        newFrame.revalidate();
        //try {Thread.sleep(4000);} catch (InterruptedException e) {e.printStackTrace();}
    }
     */
}
